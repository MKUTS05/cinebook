//
//  MockData.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//

struct MockData {
    static let movies: [Movie] = [
        Movie(
            title: "Avengers",
            genre: "Action",
            duration: 143,
            rating: "PG",
            sessions: ["5:00 PM", "7:30 PM", "9:45 PM"]
        ),
        Movie(
            title: "Dune 2",
            genre: "Sci-Fi",
            duration: 166,
            rating: "M",
            sessions: ["6:00 PM", "8:30 PM"]
        ),
        Movie(
            title: "Kung Fu Panda 4",
            genre: "Animation",
            duration: 94,
            rating: "PG",
            sessions: ["4:00 PM", "6:15 PM"]
        )
    ]
}
