//
//  ShowTimeSelectionView.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//
import SwiftUI

struct ShowtimeSelectionView: View {
    let movie: Movie

    var body: some View {
        List(movie.sessions, id: \.self) { time in
            NavigationLink(
                destination: SeatSelectionView(movie: movie, time: time)
            ) {
                Text(time)
                    .font(.title3)
            }
        }
        .navigationTitle(movie.title)
    }
}
