//
//  Seat.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//

import Foundation

struct Seat: Identifiable, Hashable, Codable {
    let id = UUID()
    let row: Int
    let col: Int
    var isSelected: Bool = false
}
