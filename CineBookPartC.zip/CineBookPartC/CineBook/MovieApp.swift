//
//  MovieApp.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//

import SwiftUI

@main
struct MovieApp: App {
    @StateObject var store = BookingStore()

    var body: some Scene {
        WindowGroup {
            ContentView()             
                .environmentObject(store)
        }
    }
}
