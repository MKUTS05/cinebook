//
//  ContentView.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//
import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            List(MockData.movies) { movie in
                NavigationLink(
                    destination: ShowtimeSelectionView(movie: movie)
                ) {
                    VStack(alignment: .leading) {
                        Text(movie.title)
                            .font(.headline)
                        Text("\(movie.genre) · \(movie.duration) · \(movie.rating)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("CineBook")
        }
    }
}
