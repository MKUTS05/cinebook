//
//  Movie.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//

import Foundation

struct Movie: Identifiable {
    let id = UUID()
    let title: String
    let genre: String
    let duration: Int
    let rating: String    
    let sessions: [String]
}
