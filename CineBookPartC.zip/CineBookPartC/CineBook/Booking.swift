//
//  Booking.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//

import SwiftUI

import Foundation

struct Booking: Identifiable, Codable {
    let id = UUID()
    let movieTitle: String
    let sessionTime: String
    let seats: [Seat]
    let date: Date
    var isCancelled: Bool = false
}
