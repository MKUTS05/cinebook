//
//  SeatSelectionView.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//
import SwiftUI

struct SeatSelectionView: View {
    let movie: Movie
    let time: String

    let rows = 6
    let cols = 8
    let seatPrice = 12.0

    @State private var seats: [[Seat]]
    @State private var selectedSeats: [Seat] = []

    init(movie: Movie, time: String) {
        self.movie = movie
        self.time = time

        var grid: [[Seat]] = []
        for r in 0..<rows {
            var rowArray: [Seat] = []
            for c in 0..<cols {
                rowArray.append(Seat(row: r, col: c))
            }
            grid.append(rowArray)
        }
        _seats = State(initialValue: grid)
    }

    var totalPrice: Double {
        Double(selectedSeats.count) * seatPrice
    }

    var body: some View {
        VStack {
            Text(movie.title)
                .font(.title2)
            Text(time)
                .foregroundColor(.secondary)

            VStack(spacing: 10) {
                ForEach(0..<rows, id: \.self) { r in
                    HStack(spacing: 10) {
                        ForEach(0..<cols, id: \.self) { c in
                            let seat = seats[r][c]

                            Circle()
                                .fill(seat.isSelected ? Color.green : Color.gray)
                                .frame(width: 30, height: 30)
                                .onTapGesture {
                                    toggleSeat(r, c)
                                }
                        }
                    }
                }
            }
            .padding()

            Spacer()

            Text("Total: $\(totalPrice, specifier: "%.2f")")
                .font(.title3)
                .padding(.bottom, 8)

            NavigationLink(
                destination: BookingConfirmationView(
                    movie: movie,
                    time: time,
                    selectedSeats: selectedSeats
                )
            ) {
                Text("Continue")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(selectedSeats.isEmpty ? Color.gray : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .disabled(selectedSeats.isEmpty)
            .padding(.horizontal)
            .padding(.bottom)
        }
    }

    func toggleSeat(_ r: Int, _ c: Int) {
        seats[r][c].isSelected.toggle()

        if seats[r][c].isSelected {
            selectedSeats.append(seats[r][c])
        } else {
            selectedSeats.removeAll { $0.id == seats[r][c].id }
        }
    }
}
