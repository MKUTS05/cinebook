//
//  BookingConfirmationView.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//
import SwiftUI

struct BookingConfirmationView: View {
    @EnvironmentObject var store: BookingStore
    @State private var goToBookings = false

    let movie: Movie
    let time: String
    let selectedSeats: [Seat]

    var body: some View {
        VStack(spacing: 20) {
            NavigationLink(
                destination: MyBookingsView(),
                isActive: $goToBookings
            ) { EmptyView() }

            Text("Confirm Booking")
                .font(.title)

            Text("Movie: \(movie.title)")
            Text("Time: \(time)")
            Text("Seats: \(seatListString())")
                .multilineTextAlignment(.center)

            Spacer()

            Button(action: saveBooking) {
                Text("Confirm Booking")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.horizontal)
            .padding(.bottom)
        }
        .padding(.top)
    }

    func seatListString() -> String {
        selectedSeats
            .map { "R\($0.row + 1)C\($0.col + 1)" }
            .joined(separator: ", ")
    }

    func saveBooking() {
        let booking = Booking(
            movieTitle: movie.title,
            sessionTime: time,
            seats: selectedSeats,
            date: Date()
        )

        store.bookings.append(booking)
        goToBookings = true
    }
}
