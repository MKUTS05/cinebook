//
//  MyBookingsView.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//
import SwiftUI

struct MyBookingsView: View {
    @EnvironmentObject var store: BookingStore

    var body: some View {
        List {
            ForEach(store.bookings) { booking in
                NavigationLink(destination: BookingDetailView(booking: booking)) {
                    VStack(alignment: .leading) {
                        Text(booking.movieTitle).font(.headline)
                        Text(booking.sessionTime)
                        Text("Seats: \(booking.seats.count)")
                    }
                }
            }
        }
        .navigationTitle("My Bookings")
    }
}

struct BookingDetailView: View {
    @EnvironmentObject var store: BookingStore
    let booking: Booking

    var body: some View {
        VStack(spacing: 20) {
            Text(booking.movieTitle).font(.title)
            Text("Time: \(booking.sessionTime)")
            Text("Seats: \(seatList())")

            if !booking.isCancelled {
                Button("Cancel Booking") {
                    cancel()
                }
                .padding()
                .background(Color.red)
                .foregroundColor(.white)
                .cornerRadius(10)
            } else {
                Text("Booking Cancelled")
                    .foregroundColor(.red)
            }

            Spacer()
        }
        .padding()
    }

    func seatList() -> String {
        booking.seats.map { "R\($0.row+1)C\($0.col+1)" }.joined(separator: ", ")
    }

    func cancel() {
        if let index = store.bookings.firstIndex(where: { $0.id == booking.id }) {
            store.bookings[index].isCancelled = true
        }
    }
}
