//
//  BookingStore.swift
//  CineBook
//
//  Created by Tejass on 10/5/2026.
//
import SwiftUI
import Foundation

class BookingStore: ObservableObject {
    @Published var bookings: [Booking] = [] {
        didSet { save() }
    }

    init() {
        load()
    }

    private let key = "bookings"

    func save() {
        if let encoded = try? JSONEncoder().encode(bookings) {
            UserDefaults.standard.set(encoded, forKey: key)
        }
    }

    func load() {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([Booking].self, from: data) {
            bookings = decoded
        }
    }
}

